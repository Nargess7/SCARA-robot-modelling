clc
clear all
close all

syms t1 t2 t3 t4 d1 d3 L1 L2 L3 L4 Lo1 Lo2 Lo3 Lo4 po a m1 m2 m3 m4 gr dt1 dt2 dt3 dt4 dd3
d1=0
Lo2=L2/2
Lo1=L1/2
Lo3=L3/2
Lo4=L4/2
H1_0=[cos(t1) -sin(t1) 0 0;sin(t1) cos(t1) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 Lo1;0 1 0 0;0 0 1 0;0 0 0 1];
h1_0=[cos(t1) -sin(t1) 0 0;sin(t1) cos(t1) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 L1;0 1 0 0;0 0 1 0;0 0 0 1];
H2_1=[cos(t2) -sin(t2) 0 0;sin(t2) cos(t2) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 Lo2;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 0;0 cosd(-180) -sind(-180) 0;0 sind(-180) cosd(-180) 0;0 0 0 1]
h2_1=[cos(t2) -sin(t2) 0 0;sin(t2) cos(t2) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 L2;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 0;0 cosd(-180) -sind(-180) 0;0 sind(-180) cosd(-180) 0;0 0 0 1]
H3_2=[1 0 0 0;0 1 0 0;0 0 1 Lo3+d3;0 0 0 1]
h3_2=[1 0 0 0;0 1 0 0;0 0 1 L3+d3;0 0 0 1]
H4_3=[cos(t4) -sin(t4) 0 0;sin(t4) cos(t4) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 Lo4;0 0 0 1]
h4_3=[cos(t4) -sin(t4) 0 0;sin(t4) cos(t4) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 L4;0 0 0 1]

H1_0=H1_0
h1_0=h1_0
H2_0=h1_0*H2_1
H2_0=simplify(H2_0)
h2_0=h1_0*h2_1
h2_0=simplify(h2_0)
H3_0=h1_0*h2_1*H3_2
H3_0=simplify(H3_0)
h3_0=h1_0*h2_1*h3_2
h3_0=simplify(h3_0)
H4_0=h1_0*h2_1*h3_2*H4_3
H4_0=simplify(H4_0)
h4_0=h1_0*h2_1*h3_2*h4_3
h4_0=simplify(h4_0)

O1_0=H1_0(1:3,4);
o1_0=h1_0(1:3,4);
R1_0=H1_0(1:3,1:3);
O2_0=H2_0(1:3,4);
o2_0=h2_0(1:3,4);
R2_0=H2_0(1:3,1:3);
O3_0=H3_0(1:3,4);
o3_0=h3_0(1:3,4);
R3_0=H1_0(1:3,1:3);
O4_0=H4_0(1:3,4);
o4_0=h4_0(1:3,4);
R4_0=H2_0(1:3,1:3);

Jvo1=[cross([0;0;1],O1_0) zeros(3,1) zeros(3,1) zeros(3,1)];
Jwo1=[[0;0;1] zeros(3,1) zeros(3,1) zeros(3,1)];
Jvo2=[cross([0;0;1],O2_0) cross(R1_0*[0;0;1],(O2_0-o1_0)) zeros(3,1) zeros(3,1)];
Jwo2=[[0;0;1] R1_0*[0;0;1] zeros(3,1) zeros(3,1)];
Jvo3=[cross([0;0;1],O3_0)  cross(R1_0*[0;0;1],(O3_0-o1_0)) R2_0*[0;0;1] zeros(3,1)];
Jwo3=[zeros(3,1) zeros(3,1) zeros(3,1) zeros(3,1)];
Jvo4=[cross([0;0;1],O4_0) cross(R1_0*[0;0;1],(O4_0-o1_0)) R2_0*[0;0;1] cross(R3_0*[0;0;1],(O4_0-o3_0))];
Jwo4=[[0;0;1] R1_0*[0;0;1] zeros(3,1) R3_0*[0;0;1]];
J=[Jvo1;Jvo2;Jvo3;Jvo4;R1_0.'*Jwo1;R2_0.'*Jwo2;R3_0.'*Jwo3;R4_0.'*Jwo4]

I1=m1*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I2=m2*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I3=m3*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I4=m4*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
% G
gi=[0;0;gr]
gr=9.81
G=[gi*m1;gi*m2;gi*m3;gi*m4;0;0;0;0;0;0;0;0;0;0;0;0]
G=J.'*G
% M
f1=[m1*eye(3,3),zeros(3,9);zeros(3,3),m2*eye(3,3),zeros(3,6);zeros(3,6),m3*eye(3,3),zeros(3,3);zeros(3,9),m4*eye(3,3)]
f2=zeros(12,12)
f12=[f1;f2]
f3=[I1,zeros(3,9);zeros(3,3),I2,zeros(3,6);zeros(3,6),I3,zeros(3,3);zeros(3,9),I4]
f32=[f2;f3]
m=[f12,f32]
M=J.'*m*J
M=simplify(M)
%C
theta=[t1;t2;d3;t4]
dtheta=[dt1;dt2;dd3;dt4]
w1=I1*R1_0.'*Jwo1*dtheta
w2=I2*R2_0.'*Jwo2*dtheta
w3=I3*R3_0.'*Jwo3*dtheta
w4=I4*R4_0.'*Jwo4*dtheta

S11=[0 -w1(3) w1(2) ; w1(3) 0 -w1(1) ; -w1(2) w1(1) 0 ]
S22=[0 -w2(3) w2(2) ; w2(3) 0 -w2(1) ; -w2(2) w2(1) 0 ]
S33=[0 -w3(3) w3(2) ; w3(3) 0 -w3(1) ; -w3(2) w3(1) 0 ]
S44=[0 -w4(3) w4(2) ; w4(3) 0 -w4(1) ; -w4(2) w4(1) 0 ]

S11=simplify(S11)
S22=simplify(S22)
S33=simplify(S33)
S44=simplify(S44)
 
A=zeros(24,12)
D=zeros(12,12)
B=[-S11,zeros(3,9);zeros(3,3),-S22,zeros(3,6);zeros(3,6),-S33,zeros(3,3);zeros(3,9),-S44]
E=[D;B]
H=[A,E]
DJ=diff(J,t1)*dt1+diff(J,t2)*dt2+diff(J,d3)*dd3+diff(J,t4)*dt4
C=J.'*(m*DJ+H*J)
C=simplify(C)
