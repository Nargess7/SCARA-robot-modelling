clc
clear all
close all

syms t1 t2 t3 t4 d1 d3 L1 L2 L3 L4 Lo1 Lo2 Lo3 Lo4 a m1 m2 m3 m4 gr dt1 dt2 dd3 dt4
d1=0
Lo2=L2/2
Lo1=L1/2
Lo3=L3/2
Lo4=L4/2

H1_0=[cos(t1) -sin(t1) 0 0;sin(t1) cos(t1) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 Lo1;0 1 0 0;0 0 1 0;0 0 0 1];
h1_0=[cos(t1) -sin(t1) 0 0;sin(t1) cos(t1) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 L1;0 1 0 0;0 0 1 0;0 0 0 1];
H2_1=[cos(t2) -sin(t2) 0 0;sin(t2) cos(t2) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 Lo2;0 1 0 0;0 0 1 0;0 0 0 1]*...
    [1 0 0 0;0 cosd(-180) -sind(-180) 0;...
    0 sind(-180) cosd(-180) 0;0 0 0 1]
h2_1=[cos(t2) -sin(t2) 0 0;sin(t2) cos(t2) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 L2;0 1 0 0;0 0 1 0;0 0 0 1]*....
    [1 0 0 0;0 cosd(-180) -sind(-180) 0;...
    0 sind(-180) cosd(-180) 0;0 0 0 1]
H3_2=[1 0 0 0;0 1 0 0;0 0 1 Lo3+d3;0 0 0 1]
h3_2=[1 0 0 0;0 1 0 0;0 0 1 L3+d3;0 0 0 1]
H4_3=[cos(t4) -sin(t4) 0 0;sin(t4) cos(t4) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 Lo4;0 0 0 1]
h4_3=[cos(t4) -sin(t4) 0 0;sin(t4) cos(t4) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 L4;0 0 0 1]


H1_0=H1_0
h1_0=h1_0
H2_0=h1_0*H2_1
H2_0=simplify(H2_0)
h2_0=h1_0*h2_1
h2_0=simplify(h2_0)
H3_0=h1_0*h2_1*H3_2
H3_0=simplify(H3_0)
h3_0=h1_0*h2_1*h3_2
h3_0=simplify(h3_0)
H4_0=h1_0*h2_1*h3_2*H4_3
H4_0=simplify(H4_0)
h4_0=h1_0*h2_1*h3_2*h4_3
h4_0=simplify(h4_0)

O1_0=H1_0(1:3,4);
o1_0=h1_0(1:3,4);
R1_0=H1_0(1:3,1:3);
O2_0=H2_0(1:3,4);
o2_0=h2_0(1:3,4);
R2_0=H2_0(1:3,1:3);
O3_0=H3_0(1:3,4);
o3_0=h3_0(1:3,4);
R3_0=H1_0(1:3,1:3);
O4_0=H4_0(1:3,4);
o4_0=h4_0(1:3,4);
R4_0=H2_0(1:3,1:3);

Jvo1=[cross([0;0;1],O1_0) zeros(3,1) zeros(3,1) zeros(3,1)];
Jwo1=[[0;0;1] zeros(3,1) zeros(3,1) zeros(3,1)];
Jvo2=[cross([0;0;1],O2_0) cross(R1_0*[0;0;1],(O2_0-o1_0)) zeros(3,1) zeros(3,1)];
Jwo2=[[0;0;1] R1_0*[0;0;1] zeros(3,1) zeros(3,1)];
Jvo3=[cross([0;0;1],O3_0)  cross(R1_0*[0;0;1],(O3_0-o1_0)) R2_0*[0;0;1] zeros(3,1)];
Jwo3=[zeros(3,1) zeros(3,1) zeros(3,1) zeros(3,1)];
Jvo4=[cross([0;0;1],O4_0) cross(R1_0*[0;0;1],(O4_0-o1_0)) R2_0*[0;0;1] cross(R3_0*[0;0;1],(O4_0-o3_0))];
Jwo4=[[0;0;1] R1_0*[0;0;1] zeros(3,1) R3_0*[0;0;1]];

I1=m1*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I2=m2*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I3=m3*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
I4=m4*diag([(a^2/(6)) (a^2/(6)) (a^2/(6))])
%M
M=m1*Jvo1.'*Jvo1+m2*Jvo2.'*Jvo2+m3*Jvo3.'*Jvo3+m4*Jvo4.'*Jvo4+Jwo1.'*R1_0*I1*R1_0.'*Jwo1+Jwo2.'*R2_0*I2*R2_0.'*Jwo2+...
    Jwo3.'*R3_0*I3*R3_0.'*Jwo3+Jwo4.'*R4_0*I4*R4_0.'*Jwo4
M=simplify(M)
%g
P=sym(zeros(1,1));
m=[m1 m2 m3 m4];
theta=[t1 t2 d3 t4]
O=[O1_0 O2_0 O3_0 O4_0];
for i=1:4
    P=m(i)*[0 0 gr]*O(:,i)+P;
end
g=sym(zeros(4,1));
for i=1:4
    g(i)=diff(P,theta(i));
end
g=simplify(g);
%C
c=sym([]);
for i=1:4
    for j=1:4
        for k=1:4
            if i>j
            c(i,j,k)=c(j,i,k);
            else
            c(i,j,k)=0.5*(diff(M(k,j),theta(i))+diff(M(k,i),theta(j))-diff(M(i,j),theta(k)));
            end
        end
    end
end

C=sym(zeros(4,4));
dtheta=[dt1 dt2 dd3 dt4];
for k=1:4
    for j=1:4
        for i=1:4
            C(k,j)=c(i,j,k)*dtheta(i)+C(k,j);
        end
    end
end
C=simplify(C);
%% Mdot-2C
Mdot=diff(M,t1)*dt1+diff(M,t2)*dt2+diff(M,d3)*dd3+diff(M,t4)*dt4
aa=Mdot-2*C
aa=simplify(aa)
x=[1;2;3;4]
bb=x.'*aa*x


