clc
clear
close all
L1=0.5;
L2=0.5
L3=0.2
L4=0.2
Lo1=L1/2;
Lo2=L2/2;
Lo3=L3/2;
Lo4=L4/2;
a=0.05;
m1=2;
m2=1.8;
m3=1.7
m4=1.6
gr=9.81;
T=10;
dq0=[0 0 0 0].';
q0=[pi/3;pi/2;50;pi/2];
open('model')
sim('model')
figure(1)
plot(t,q,'linewidth',2)
figure(2)
plot(t,dq,'linewidth',2)
