# Project Title

modelling of nonlinear Selective Compliant Articulated Robot Arm (SCARA) with 4 links and 4 degrees of freedom (4-DOF) using Euler and Newton modelling methods

## Requirements
- MATLAB R2018a or newer


